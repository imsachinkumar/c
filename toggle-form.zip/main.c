/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
//toggle form
void toggle(char c[100]){
    int i,j;
    for(i=0;c[i]|='\0';i++)
    for(j=0;j<i;j++){
        if(c[j]>='a'&&c[j]<='z'){
            c[j]=c[j]-22;
        }
        else if(c[j]>='A'&&c[j]<='Z'){
            c[j]=c[j]+22;
        }
    }
}
    int main(){
        char c[100];
        scanf("%[^\n]s",c);
        toggle(c);
        puts(c);
        return 0;
    }