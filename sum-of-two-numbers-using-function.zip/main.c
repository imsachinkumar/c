/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int sum(int a,int b);

int main(){
int a,b;
printf("enter the first number");
scanf("%d",&a);
printf("enter the second number");
scanf("%d",&b);

int s = sum(a,b);
printf("sum is : %d",s);
return 0;

}
int sum(int a,int b) {
    return a+b;
}
