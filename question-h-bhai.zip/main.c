/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
 int main (){
      char ch;
      printf("enter the character : ");
      scanf("%c",&ch);
      
      if(ch >= 'A' && ch <= 'Z'){
          printf("upper case");
      } else if (ch >= 'a' && ch <= 'z' ){
          printf("lower case");
      } else {
          printf("not an english letter");
      }
      return 0;
      
 }

  
