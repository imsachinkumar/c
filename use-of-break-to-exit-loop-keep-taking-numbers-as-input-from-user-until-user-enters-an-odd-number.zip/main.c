/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//keep taking numbers as input from user until user enters an odd number
int main()
{
    int n;
    do{
        printf("enter the number");
        scanf("%d",&n);
        printf("%d\n",n);
        
        if(n%2!=0){
            break;
        }
        
    } while(1);
    printf("come out");

    return 0;
}

