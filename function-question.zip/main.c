/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

void doWork(int a, int b, int *sum, int *prod, int *avg);

int main() {
    int a=8,b=4;
    int sum , prod ,avg;

    doWork(a, b, &sum, &prod, &avg);

    printf("sum is : %d\n, prod is : %d\n, avg is : %d\n", sum, prod,avg);

    return 0;
    
}

void doWork(int a, int b, int *sum, int *prod, int *avg){
    *sum = a+b;
    *prod = a*b;
    *avg = (a+b)/2;
}