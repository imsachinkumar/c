/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

void swap(int *a,int *b);

int main(){
    int a=3, b=5;
    swap(&a,&b);
    printf("a=%d\n,b=%d\n",a,b);

    return 0;
}
void swap(int *a,int*b){
    int t=*a;
    *a=*b;
    *b=t;

    
}
