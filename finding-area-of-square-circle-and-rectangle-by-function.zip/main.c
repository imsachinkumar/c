/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<math.h>

float squareArea(float side);
float circleArea(float radius);
float rectangleArea(float a, float b);

int main(){
float side = 9.0;
printf("area of square is : %f",squareArea(side));
    return 0;
}
float squareArea(float side){
    return side * side;
}
float circleArea(float rad) {
    return 3.14 * rad * rad;
}
float rectangleArea(float a, float b) {
    return a * b;
}