/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
int main(){
    printHW(5);

    return 0;
}
//recursive function
void printHW(int n) {
    if (n==0){
        return;
    }
    printf("Hello World\n");
    printHW(n-1);
}
#include <stdio.h>
//sum of n natural numbers
int sum(int n);

int main(){
    printf("sum is : %d",sum(5));
    return 0;
}
 
 int sum(int n) {
    if (n==1){
        return 1;
    }
    int sumNm1=sum(n-1);//sum of 1 to n
    int sumN=sumNm1+n;
    return sumN;

 }