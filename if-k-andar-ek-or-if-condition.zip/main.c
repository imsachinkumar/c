/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main (){
    int marks;
    printf("enter the marks");
    scanf("%d", &marks);
    
    if ( marks >= 0 && marks<=30){
        printf("fail");
    } else if(marks > 30 && marks <= 100){
        printf("pass");
    } else {
        printf ("wrong marks");
    }
    return 0;
}

    
