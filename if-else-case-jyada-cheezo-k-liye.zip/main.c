/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main (){
    int marks;
    printf("enter the marks : ");
    scanf("%d", &marks);
    
    if (marks < 30) {
        printf("c");
    } else if ( marks <= 30 && marks < 70){
        printf("b");
    } else if (marks >= 70 && marks < 90) {
        printf("a");
    } else {
        printf("a++");
    }
    return 0;
}