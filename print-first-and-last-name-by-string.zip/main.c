/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void printString(char arr[]);

int main() {
    char firstname[] ="sachin";
    char lastname[] ="thakurela";
    
    printString(firstname);
    printString(lastname);
    return 0;

}

void printString(char arr[]){
    for(int i=0;arr[i]!='\0';i++){
    printf("%c",arr[i]);
}

printf("\n");
}