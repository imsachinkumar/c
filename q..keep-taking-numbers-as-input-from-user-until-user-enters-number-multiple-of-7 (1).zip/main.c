/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//keep taking numbers as input from user until user enters number multiple of 7
int main()
{
    int n;
    do{
        printf("enter the number");
        scanf("%d",&n);
        printf("%d\n",n);
        
        if(n%7==0)//multiple of 7
        {
            break;
        }
        
    } while(1);
    printf("come out \n");

    return 0;
}
